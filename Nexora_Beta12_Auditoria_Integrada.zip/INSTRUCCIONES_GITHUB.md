# Instrucciones para GitHub Actions — Nexora Beta 12

## A. Subir el proyecto

Descomprime `Nexora_Beta12_Auditoria_Integrada.zip`. Sube el contenido del proyecto directamente a la raíz del repositorio que usarás para Nexora. Si ya existe el repositorio, conserva una copia de su estado anterior y evita crear una carpeta contenedora adicional.

La raíz debe mostrar al menos:
- `.github/workflows/main.yml`
- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`

## B. Workflow de compilación

El archivo `.github/workflows/main.yml` incluido ya configura Java 17 y Gradle 8.9, comprueba la estructura y versión, compila el APK de prueba y verifica que el archivo generado no esté vacío. No necesitas copiar un workflow distinto.

El workflow mantenido en el ZIP es la fuente de verdad para la compilación.


## C. Descargar el APK

En GitHub, abre Actions, entra en la ejecución más reciente con marca verde y descarga `NEXORA-APK-v2.0-beta12` desde Artifacts. Verifica la fecha de ejecución antes de instalarlo para no confundirlo con una APK vieja.

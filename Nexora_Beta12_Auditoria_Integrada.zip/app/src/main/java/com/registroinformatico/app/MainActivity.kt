package com.registroinformatico.app

import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import android.os.Bundle
import android.app.DatePickerDialog
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101E30)
private val Panel2 = Color(0xFF17283D)
private val Cyan = Color(0xFF48DDF5)
private val Blue = Color(0xFF528BFF)
private val Violet = Color(0xFF9A8CFF)
private val Green = Color(0xFF5DE0B0)
private val Orange = Color(0xFFFFB86B)
private val Muted = Color(0xFF9BAFC7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash nativo: aparece antes de que Compose empiece a dibujar.
        // No mantenemos la pantalla artificialmente mientras la app ya está lista.
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Crear el canal y programar recordatorios persistentes; WorkManager los conserva tras reinicios.
        NexoraReminderWorker.createNotificationChannel(this)
        val reminder = PeriodicWorkRequestBuilder<NexoraReminderWorker>(2, TimeUnit.HOURS)
            .setInitialDelay(NexoraReminderWorker.delayUntilNextSlot(), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            NexoraReminderWorker.WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, reminder
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }

        window.statusBarColor = android.graphics.Color.rgb(3, 10, 28)
        window.navigationBarColor = android.graphics.Color.rgb(3, 10, 28)

        // Guardar el contexto de la actividad antes de entrar en AnimatedContent.
        val activityContext = this

        setContent {
            var showSplash by remember { mutableStateOf(true) }

            LaunchedEffect(Unit) {
                // Duración suficiente para completar la entrada del logotipo y el texto.
                delay(2850)
                showSplash = false
            }

            AnimatedContent(
                targetState = showSplash,
                transitionSpec = {
                    if (initialState && !targetState) {
                        (
                            fadeIn(animationSpec = tween(520, easing = FastOutSlowInEasing)) +
                                slideInVertically(
                                    animationSpec = tween(560, easing = FastOutSlowInEasing),
                                    initialOffsetY = { height -> height / 18 }
                                ) + scaleIn(initialScale = 0.975f, animationSpec = tween(520, easing = FastOutSlowInEasing))
                        ) togetherWith (
                            fadeOut(animationSpec = tween(300, easing = FastOutLinearInEasing)) +
                                scaleOut(targetScale = 1.025f, animationSpec = tween(300, easing = FastOutLinearInEasing))
                        )
                    } else {
                        fadeIn(animationSpec = tween(300, easing = FastOutSlowInEasing)) togetherWith
                            fadeOut(animationSpec = tween(220, easing = FastOutSlowInEasing))
                    }
                },
                label = "transicion_bienvenida_inicio"
            ) { mostrarBienvenida ->
                if (mostrarBienvenida) {
                    StartupScreen()
                } else {
                    RegistroApp(activityContext)
                }
            }
        }
    }
}

@Composable
private fun StartupScreen() {
    val motion = rememberInfiniteTransition(label = "nexora_splash_motion")
    val haloScale by motion.animateFloat(
        initialValue = 0.88f, targetValue = 1.16f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "halo_scale"
    )
    val haloAlpha by motion.animateFloat(
        initialValue = 0.22f, targetValue = 0.62f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "halo_alpha"
    )
    val logoScale by animateFloatAsState(
        targetValue = 1f,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = 220f),
        label = "logo_entrance"
    )
    var logoVisible by remember { mutableStateOf(false) }
    var titleVisible by remember { mutableStateOf(false) }
    var taglineVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(180)
        logoVisible = true
        delay(260)
        titleVisible = true
        delay(220)
        taglineVisible = true
    }
    val logoAlpha by animateFloatAsState(if (logoVisible) 1f else 0f, tween(650, easing = FastOutSlowInEasing), label = "logo_alpha")
    val titleAlpha by animateFloatAsState(if (titleVisible) 1f else 0f, tween(550, easing = FastOutSlowInEasing), label = "title_alpha")
    val taglineAlpha by animateFloatAsState(if (taglineVisible) 1f else 0f, tween(550, easing = FastOutSlowInEasing), label = "tagline_alpha")
    val titleOffset by animateFloatAsState(if (titleVisible) 0f else 18f, tween(550, easing = FastOutSlowInEasing), label = "title_offset")
    val taglineOffset by animateFloatAsState(if (taglineVisible) 0f else 14f, tween(550, easing = FastOutSlowInEasing), label = "tagline_offset")

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF020817), Color(0xFF03132C), Color(0xFF02091A)))
        ),
        contentAlignment = Alignment.Center
    ) {
        // Circuitos finos y destellos ambientales, dibujados para adaptarse a cualquier pantalla.
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val lineColor = Color(0xFF1689D8).copy(alpha = 0.13f)
            for (i in 0..7) {
                val y = h * (0.12f + i * 0.105f)
                val shift = if (i % 2 == 0) 0.10f else 0.90f
                val x = w * shift
                drawLine(lineColor, Offset(if (i % 2 == 0) 0f else w, y), Offset(x, y + 18f), strokeWidth = 1.2f)
                drawLine(lineColor.copy(alpha = 0.7f), Offset(x, y + 18f), Offset(x, y + 48f), strokeWidth = 1f)
            }
            drawCircle(Color(0xFF006DFF).copy(alpha = 0.045f), radius = w * 0.68f, center = Offset(w * 0.5f, h * 0.43f))
            drawCircle(Color(0xFF00E5FF).copy(alpha = 0.035f), radius = w * 0.45f, center = Offset(w * 0.5f, h * 0.43f))
            // Líneas de circuito en las esquinas inferiores.
            drawLine(lineColor, Offset(0f, h * 0.89f), Offset(w * 0.44f, h * 0.99f), strokeWidth = 1.2f)
            drawLine(lineColor, Offset(w, h * 0.89f), Offset(w * 0.56f, h * 0.99f), strokeWidth = 1.2f)
        }

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(190.dp)) {
                Box(
                    Modifier.size(164.dp).graphicsLayer {
                        scaleX = haloScale
                        scaleY = haloScale
                        alpha = haloAlpha * logoAlpha
                    }.background(
                        Brush.radialGradient(listOf(Color(0xFF087BFF).copy(alpha = 0.28f), Color.Transparent)),
                        CircleShape
                    )
                )
                Box(
                    Modifier.size(150.dp).graphicsLayer { scaleX = haloScale; scaleY = haloScale; alpha = haloAlpha * logoAlpha }
                        .background(Color.Transparent, RoundedCornerShape(34.dp))
                        .then(Modifier),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRoundRect(
                            brush = Brush.sweepGradient(listOf(Color(0xFF00E5FF), Color(0xFF1478FF), Color(0xFF7A38FF), Color(0xFF00E5FF)), center = Offset(size.width / 2, size.height / 2),),
                            style = Stroke(width = 3.2.dp.toPx()),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(34.dp.toPx())
                        )
                    }
                }
                Image(
                    painter = painterResource(id = R.mipmap.ic_launcher),
                    contentDescription = "Logotipo de Nexora",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(124.dp).graphicsLayer {
                        alpha = logoAlpha
                        scaleX = if (logoVisible) 1f else 0.72f
                        scaleY = if (logoVisible) 1f else 0.72f
                    }
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "NEXORA",
                color = Color.White,
                fontSize = 35.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.4.sp,
                modifier = Modifier.graphicsLayer { alpha = titleAlpha; translationY = titleOffset }
            )
            Spacer(Modifier.height(22.dp))
            Text(
                "GESTIÓN INTELIGENTE DE SOPORTE TÉCNICO",
                color = Color(0xFF9DDDF4),
                fontSize = if (maxWidth < 380.dp) 12.sp else 14.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.35.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = taglineAlpha; translationY = taglineOffset }
            )
        }
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 25.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(3) { index ->
                    val active = index == 1
                    Box(
                        Modifier.width(if (active) 28.dp else 8.dp).height(6.dp)
                            .background(if (active) Color(0xFF42E6FF) else Color(0xFF2B5798), CircleShape)
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "VERSIÓN 2.0 BETA 12",
                color = Color(0xFF718EBA),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.5.sp
            )
        }
    }
}

data class Report(
    val id: Long = System.currentTimeMillis(), val person: String, val department: String,
    val software: String, val type: String, val priority: String, val problem: String,
    val diagnosis: String, val solution: String, val minutes: Int, val status: String,
    val date: Long = System.currentTimeMillis(), val technician: String = "", val notes: String = "", val closedAt: Long = 0L
)

private fun Report.toJson() = JSONObject().apply {
    put("id", id); put("person", person); put("department", department); put("software", software)
    put("type", type); put("priority", priority); put("problem", problem); put("diagnosis", diagnosis)
    put("solution", solution); put("minutes", minutes); put("status", status); put("date", date)
    put("technician", technician); put("notes", notes); put("closedAt", closedAt)
}
private fun JSONObject.str(k: String) = optString(k, "")
private fun JSONObject.toReport() = Report(optLong("id"), str("person"), str("department"), str("software"), str("type"), str("priority"), str("problem"), str("diagnosis"), str("solution"), optInt("minutes"), str("status"), optLong("date", System.currentTimeMillis()), str("technician"), str("notes"), optLong("closedAt", 0L))
private class ReportStore(context: Context) {
    private val prefs = context.getSharedPreferences("registro_informatico", Context.MODE_PRIVATE)
    fun load(): List<Report> = runCatching {
        val a = JSONArray(prefs.getString("reports", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).toReport() }.sortedByDescending { it.date }
    }.getOrDefault(emptyList())
    fun save(list: List<Report>) { val a = JSONArray(); list.forEach { a.put(it.toJson()) }; prefs.edit().putString("reports", a.toString()).apply() }
}

private data class Tab(val label: String, val icon: ImageVector)
private val tabs = listOf(Tab("Inicio", Icons.Default.Dashboard), Tab("Reportes", Icons.Default.Assignment), Tab("Análisis", Icons.Default.QueryStats), Tab("Informes", Icons.Default.Assessment), Tab("Ajustes", Icons.Default.Settings))

@Composable
private fun RegistroApp(context: Context) {
    val store = remember { ReportStore(context) }
    var reports by remember { mutableStateOf(store.load()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showGlobalNotifications by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Report?>(null) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todos") }
    fun persist(next: List<Report>) { reports = next.sortedByDescending { it.date }; store.save(reports) }
    var transferMessage by remember { mutableStateOf<String?>(null) }
    var pendingBackupImport by remember { mutableStateOf<List<Report>?>(null) }
    var reportExportRows by remember { mutableStateOf<List<Report>>(emptyList()) }
    val exportCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.bufferedWriter(Charsets.UTF_8).use { it.write("\uFEFF" + reportsToCsv(reportExportRows.ifEmpty { reports })) } }.onSuccess { transferMessage = "CSV exportado. Puedes abrirlo con Excel." }.onFailure { transferMessage = "No se pudo exportar el CSV: ${it.message}" }
    }
    val exportHtmlLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.bufferedWriter(Charsets.UTF_8).use { it.write(reportToHtml(reportExportRows)) } }.onSuccess { transferMessage = "Informe HTML exportado; puedes abrirlo en el navegador o imprimirlo como PDF." }.onFailure { transferMessage = "No se pudo exportar HTML: ${it.message}" }
    }
    val exportTxtLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.bufferedWriter(Charsets.UTF_8).use { it.write(reportToText(reportExportRows)) } }.onSuccess { transferMessage = "Informe de texto exportado." }.onFailure { transferMessage = "No se pudo exportar TXT: ${it.message}" }
    }
    val exportPdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.use { it.write(reportToPdf(reportExportRows)) } }.onSuccess { transferMessage = "Informe PDF exportado." }.onFailure { transferMessage = "No se pudo exportar PDF: ${it.message}" }
    }
    val exportReportJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.bufferedWriter(Charsets.UTF_8).use { out -> out.write(JSONArray().apply { reportExportRows.forEach { put(it.toJson()) } }.toString(2)) } }.onSuccess { transferMessage = "Informe JSON exportado." }.onFailure { transferMessage = "No se pudo exportar JSON: ${it.message}" }
    }
    val exportBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { requireNotNull(context.contentResolver.openOutputStream(uri)) { "No se pudo abrir el archivo de destino." }.bufferedWriter(Charsets.UTF_8).use { out -> out.write(JSONArray().apply { reports.forEach { put(it.toJson()) } }.toString(2)) } }.onSuccess { transferMessage = "Copia de seguridad exportada." }.onFailure { transferMessage = "No se pudo crear la copia: ${it.message}" }
    }
    val importBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() } }.mapCatching { raw ->
            val arr = JSONArray(raw); (0 until arr.length()).map { arr.getJSONObject(it).toReport() }
        }.onSuccess { imported -> pendingBackupImport = imported }.onFailure { transferMessage = "No se pudo importar la copia. Selecciona un JSON exportado por esta aplicación." }
    }
    val importCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { context.contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText().removePrefix("\uFEFF") } }.mapCatching { csvToReports(it) }.onSuccess { imported ->
            val usedIds = reports.map { it.id }.toMutableSet()
            var nextId = System.currentTimeMillis()
            val safeImported = imported.map { report ->
                var id = report.id
                if (id <= 0L || id in usedIds) {
                    while (nextId in usedIds) nextId++
                    id = nextId++
                }
                usedIds.add(id)
                report.copy(id = id)
            }
            persist(reports + safeImported)
            transferMessage = "Importados ${safeImported.size} reportes desde CSV."
        }.onFailure { transferMessage = "No se pudo leer el CSV. Usa el formato exportado por la aplicación." }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary=Cyan, secondary=Blue, background=Navy, surface=Panel, onPrimary=Navy, onBackground=Color.White, onSurface=Color.White)) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = true,
            scrimColor = Color.Black.copy(alpha = 0.62f),
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = Color(0xFF07152D),
                    drawerContentColor = Color.White,
                    modifier = Modifier.width(300.dp)
                ) {
                    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF08295A), Color(0xFF061329)))).padding(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Cyan, Blue)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Computer, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                            Spacer(Modifier.width(12.dp))
                            Column { Text("NEXORA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, letterSpacing = 1.4.sp); Text("Gestión de soporte técnico", color = Muted, fontSize = 11.sp) }
                        }
                        HorizontalDivider(color = Cyan.copy(alpha = 0.25f), modifier = Modifier.padding(vertical = 10.dp))
                        Text("MÓDULOS", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 12.dp, bottom = 8.dp, top = 6.dp))
                        tabs.forEachIndexed { i, tab ->
                            NavigationDrawerItem(
                                label = { Text(tab.label, fontWeight = if (selectedTab == i) FontWeight.Bold else FontWeight.Normal) },
                                selected = selectedTab == i,
                                onClick = { selectedTab = i; drawerScope.launch { drawerState.close() } },
                                icon = { Icon(tab.icon, null) },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = Color(0xFF103E65), selectedIconColor = Cyan, selectedTextColor = Color.White,
                                    unselectedContainerColor = Color.Transparent, unselectedIconColor = Muted, unselectedTextColor = Color(0xFFD7E5F7)
                                ),
                                modifier = Modifier.padding(vertical = 3.dp)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        HorizontalDivider(color = Cyan.copy(alpha = 0.18f))
                        Text("Cada incidencia bajo control", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        ) {
        Scaffold(containerColor=Navy, topBar = {
            NexoraPersistentBanner(
                onMenu = { drawerScope.launch { drawerState.open() } },
                onSettings = { selectedTab = 4 },
                onNotifications = { showGlobalNotifications = true },
                hasAlerts = reports.any { !it.status.equals("Resuelta", true) && !it.status.equals("Resuelto", true) }
            )
        }, bottomBar = {
            NavigationBar(containerColor=Color(0xFF0A1727), contentColor=Muted, tonalElevation=0.dp) {
                tabs.forEachIndexed { i, t -> NavigationBarItem(selected=selectedTab==i, onClick={selectedTab=i}, icon={Icon(t.icon, null)}, label={Text(t.label, maxLines=1)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Cyan, selectedTextColor=Cyan, indicatorColor=Color(0xFF18384B), unselectedIconColor=Muted, unselectedTextColor=Muted)) }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                if (showGlobalNotifications) {
                    val pendingCount = reports.count { it.status.equals("Pendiente", true) || it.status.equals("Pendientes", true) }
                    val progressCount = reports.count { it.status.equals("En proceso", true) || it.status.equals("En progreso", true) }
                    AlertDialog(
                        onDismissRequest = { showGlobalNotifications = false },
                        containerColor = Panel,
                        title = { Text("Notificaciones", color = Color.White) },
                        text = {
                            Text(
                                if (pendingCount + progressCount == 0) "No tienes reportes pendientes. Todo está al día."
                                else "Tienes $pendingCount reportes pendientes y $progressCount en proceso.",
                                color = Muted
                            )
                        },
                        confirmButton = { TextButton(onClick = { showGlobalNotifications = false }) { Text("Aceptar", color = Cyan) } }
                    )
                }
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        val direction = if (targetState >= initialState) 1 else -1
                        (
                            fadeIn(animationSpec = tween(180)) +
                                slideInVertically(
                                    animationSpec = tween(220),
                                    initialOffsetY = { height -> height / 28 * direction }
                                )
                        ) togetherWith (
                            fadeOut(animationSpec = tween(130)) +
                                androidx.compose.animation.slideOutVertically(
                                    animationSpec = tween(180),
                                    targetOffsetY = { height -> -height / 32 * direction }
                                )
                        )
                    },
                    label = "transicion_secciones"
                ) { tab ->
                    when(tab) {
                        0 -> HomeScreen(reports, onNew={editing=null;showForm=true}, onReports={selectedTab=1}, onAnalysis={selectedTab=2}, onExport={selectedTab=3}, onSettings={selectedTab=4})
                        1 -> ReportsScreen(reports, query, {query=it}, filter, {filter=it}, onNew={editing=null;showForm=true}, onOpen={editing=it;showForm=true}, onStatus={r,s->
                            val now = System.currentTimeMillis()
                            persist(reports.map { item ->
                                if (item.id != r.id) item else if (s == "Resuelta" && item.status != "Resuelta") {
                                    item.copy(status=s, closedAt=now, minutes=((now-item.date).coerceAtLeast(0L)/60000L).toInt())
                                } else if (s != "Resuelta" && item.status == "Resuelta") {
                                    item.copy(status=s, closedAt=0L, minutes=0)
                                } else item.copy(status=s)
                            })
                        }, onDelete={r->persist(reports.filterNot{it.id==r.id})})
                        2 -> AnalysisScreen(reports)
                        3 -> ExportScreen(reports, onExport={ rows, format ->
                            reportExportRows = rows
                            when (format) {
                                "CSV / Excel" -> exportCsvLauncher.launch("Nexora_Informe.csv")
                                "PDF" -> exportPdfLauncher.launch("Nexora_Informe.pdf")
                                "HTML" -> exportHtmlLauncher.launch("Nexora_Informe.html")
                                "TXT" -> exportTxtLauncher.launch("Nexora_Informe.txt")
                                else -> exportReportJsonLauncher.launch("Nexora_Informe.json")
                            }
                        })
                        else -> SettingsScreen(reports.size,
                            onExportCsv={ reportExportRows = reports; exportCsvLauncher.launch("Nexora_Reportes.csv") },
                            onExportBackup={ exportBackupLauncher.launch("Nexora_Copia_Seguridad.json") },
                            onImportBackup={ importBackupLauncher.launch(arrayOf("application/json", "text/*")) },
                            onImportCsv={ importCsvLauncher.launch(arrayOf("text/*", "application/vnd.ms-excel", "application/csv")) },
                            onClear={persist(emptyList())})
                    }
                }
                transferMessage?.let { msg -> AlertDialog(onDismissRequest={transferMessage=null}, title={Text("Transferencia de datos")}, text={Text(msg)}, confirmButton={TextButton(onClick={transferMessage=null}){Text("Aceptar")}}) }
                pendingBackupImport?.let { imported ->
                    AlertDialog(
                        onDismissRequest = { pendingBackupImport = null },
                        title = { Text("¿Restaurar esta copia?") },
                        text = { Text("La copia contiene ${imported.size} reportes. Al restaurarla, reemplazará los ${reports.size} reportes actuales. Si quieres conservarlos, cancela y exporta una copia primero.") },
                        confirmButton = {
                            TextButton(onClick = {
                                persist(imported)
                                pendingBackupImport = null
                                transferMessage = "Copia restaurada: ${imported.size} reportes."
                            }) { Text("Restaurar", color = Color(0xFFFF8796)) }
                        },
                        dismissButton = { TextButton(onClick = { pendingBackupImport = null }) { Text("Cancelar") } }
                    )
                }
                if(showForm) ReportForm(editing, onDismiss={showForm=false}, onSave={r -> persist(if(reports.any{it.id==r.id}) reports.map{if(it.id==r.id)r else it} else reports+r);showForm=false})
            }
        }
        }
    }
}

@Composable private fun PageHeader(kicker:String, title:String, subtitle:String?=null) {
    Column(Modifier.fillMaxWidth().padding(bottom=18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(40.dp).background(
                Brush.linearGradient(listOf(Color(0xFF00D9F5), Color(0xFF0878D9), Color(0xFF152E72))),
                RoundedCornerShape(13.dp)
            ), contentAlignment=Alignment.Center) {
                Icon(Icons.Default.Computer, null, tint=Color.White, modifier=Modifier.size(25.dp))
                Icon(Icons.Default.Build, null, tint=Cyan, modifier=Modifier.size(12.dp).align(Alignment.BottomEnd).offset(x=2.dp, y=2.dp))
            }
            Column { Text("NEXORA", style=MaterialTheme.typography.labelSmall, color=Cyan, fontWeight=FontWeight.ExtraBold, letterSpacing=1.2.sp); Text(kicker.uppercase(), style=MaterialTheme.typography.labelSmall, color=Muted) }
        }
        Spacer(Modifier.height(18.dp)); Text(title, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold, color=Color.White)
        if(subtitle!=null) { Spacer(Modifier.height(4.dp)); Text(subtitle, color=Muted, style=MaterialTheme.typography.bodyMedium) }
    }
}
@Composable private fun AppCard(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) { Column(
    modifier.fillMaxWidth()
        .background(Panel, RoundedCornerShape(20.dp))
        .padding(1.dp)
        .background(Brush.linearGradient(listOf(Color(0xFF23465F), Color(0xFF13263B))), RoundedCornerShape(19.dp))
        .padding(15.dp),
    content=content
) }
@Composable private fun SectionTitle(title:String, action:String?=null, onAction:(()->Unit)?=null) { Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text(title, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.SemiBold); if(action!=null) Text(action, color=Cyan, modifier=Modifier.clickable{onAction?.invoke()}, style=MaterialTheme.typography.labelLarge) } }
@Composable private fun StatCard(label:String, value:String, icon:ImageVector, tint:Color, modifier:Modifier=Modifier) { Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) { Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) { Text(label, color=Muted, style=MaterialTheme.typography.labelMedium); Icon(icon,null,tint=tint,modifier=Modifier.size(19.dp)) }; Spacer(Modifier.height(12.dp)); Text(value, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold); Spacer(Modifier.height(3.dp)); Box(Modifier.height(3.dp).fillMaxWidth().background(tint.copy(alpha=.25f), CircleShape)) { Box(Modifier.fillMaxWidth(.62f).fillMaxHeight().background(tint, CircleShape)) } } }
@Composable
private fun NexoraPersistentBanner(
    onMenu: () -> Unit,
    onSettings: () -> Unit,
    onNotifications: () -> Unit,
    hasAlerts: Boolean
) {
    Box(Modifier.fillMaxWidth().background(Color(0xFF03122F))) {
        Image(
            painter = painterResource(id = R.drawable.nexora_banner),
            contentDescription = "Nexora: gestión inteligente de soporte técnico. Cada incidencia bajo control.",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(172.dp)
        )
        IconButton(
            onClick = onMenu,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 9.dp, top = 7.dp).size(38.dp)
                .background(Color(0xCC03152F), CircleShape)
        ) {
            Icon(Icons.Default.Menu, contentDescription = "Abrir menú lateral", tint = Color(0xFF52EFFF), modifier = Modifier.size(23.dp))
        }
        Row(
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 7.dp, end = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(onClick = onSettings, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Settings, contentDescription = "Ajustes", tint = Color(0xFF52EFFF), modifier = Modifier.size(21.dp))
            }
            IconButton(onClick = onNotifications, modifier = Modifier.size(34.dp)) {
                Box {
                    Icon(Icons.Default.Notifications, contentDescription = "Notificaciones", tint = Color(0xFF52EFFF), modifier = Modifier.size(21.dp))
                    if (hasAlerts) Box(Modifier.align(Alignment.TopEnd).size(7.dp).background(Color(0xFFFF4F75), CircleShape))
                }
            }
        }
    }
}

@Composable private fun HomeScreen(
    reports: List<Report>,
    onNew: () -> Unit,
    onReports: () -> Unit,
    onAnalysis: () -> Unit,
    onExport: () -> Unit,
    onSettings: () -> Unit
) {
    val total = reports.size
    val pending = reports.count { it.status.equals("Pendiente", true) || it.status.equals("Pendientes", true) }
    val inProgress = reports.count { it.status.equals("En proceso", true) || it.status.equals("En progreso", true) }
    val resolved = reports.count { it.status.equals("Resuelta", true) || it.status.equals("Resuelto", true) }
    val urgent = reports.count { it.priority.equals("Urgente", true) && !it.status.equals("Resuelta", true) && !it.status.equals("Resuelto", true) }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF020B25), Color(0xFF041638), Color(0xFF020B24)))
        ),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF06316D), Color(0xFF071D4A), Color(0xFF082D63))),
                        RoundedCornerShape(25.dp)
                    )
                    .padding(2.dp)
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF0A3E85), Color(0xFF061A42), Color(0xFF092B60))),
                        RoundedCornerShape(23.dp)
                    )
                    .padding(horizontal = 22.dp, vertical = 18.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Total reportes", color = Color(0xFFF0F7FF), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text(total.toString(), color = Color.White, fontSize = 39.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Box(
                        Modifier.size(76.dp).background(
                            Brush.radialGradient(listOf(Color(0xFF20EFFF), Color(0xFF0876E8), Color(0x000876E8))),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Assignment, contentDescription = "Total de reportes", tint = Color(0xFF66F5FF), modifier = Modifier.size(43.dp))
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HomeStatusPill("Pendientes", pending, Color(0xFFFFBD4A), Modifier.weight(1f), Icons.Default.Schedule)
                HomeStatusPill("En proceso", inProgress, Color(0xFF27E4FF), Modifier.weight(1f), Icons.Default.Sync)
                HomeStatusPill("Resueltos", resolved, Color(0xFF28F0A0), Modifier.weight(1f), Icons.Default.CheckCircle)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                HomeStatusPill("Informes", total, Color(0xFF49E8FF), Modifier.weight(1f), Icons.Default.Assessment, onClick = onExport, prominent = true)
                HomeStatusPill("Urgentes", urgent, Color(0xFFFF5EAB), Modifier.weight(1f), Icons.Default.Warning, onClick = onReports, prominent = true)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 18.dp, top = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Accesos rápidos", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Box(
                    Modifier.weight(1f).height(3.dp).background(
                        Brush.horizontalGradient(listOf(Color(0xFF00EFFF), Color(0xFF0878FF), Color.Transparent)),
                        RoundedCornerShape(50)
                    )
                )
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                HomeQuickAction("Nuevo reporte", Icons.Default.NoteAdd, Color(0xFF16E9FF), Modifier.weight(1f), onNew)
                HomeQuickAction("Reportes", Icons.Default.Assignment, Color(0xFF28DFFF), Modifier.weight(1f), onReports)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                HomeQuickAction("Análisis", Icons.Default.QueryStats, Color(0xFF19E7FF), Modifier.weight(1f), onAnalysis)
                HomeQuickAction("Informes", Icons.Default.Assessment, Color(0xFF29DFFF), Modifier.weight(1f), onExport)
            }
        }
    }
}

@Composable private fun HomeStatusPill(
    label: String,
    value: Int,
    tint: Color,
    modifier: Modifier = Modifier,
    icon: ImageVector,
    onClick: (() -> Unit)? = null,
    prominent: Boolean = false
) {
    Column(
        modifier = modifier
            .heightIn(min = if (prominent) 94.dp else 70.dp)
            .background(
                Brush.linearGradient(
                    listOf(tint.copy(alpha = 0.19f), Color(0xFF071A3A), tint.copy(alpha = 0.10f))
                ),
                RoundedCornerShape(19.dp)
            )
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 5.dp, vertical = if (prominent) 13.dp else 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(if (prominent) 22.dp else 19.dp))
            Text(label, color = tint, fontSize = if (prominent) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(5.dp))
        Text(value.toString(), color = Color.White, fontSize = if (prominent) 28.sp else 25.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable private fun HomeQuickAction(
    label: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.height(142.dp)
            .background(
                Brush.linearGradient(listOf(Color(0xFF073C83), Color(0xFF061D49), Color(0xFF052B61))),
                RoundedCornerShape(23.dp)
            )
            .clickable(onClick = onClick)
            .padding(13.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(67.dp).background(
                Brush.radialGradient(listOf(tint.copy(alpha = 0.34f), Color(0x0016DFFF))),
                CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(43.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
private val BrushLike = Brush.linearGradient(
    colors = listOf(Color(0xFF123B58), Color(0xFF0D263F), Color(0xFF151E42))
)

@Composable private fun ReportsScreen(reports:List<Report>, query:String, onQuery:(String)->Unit, filter:String, onFilter:(String)->Unit, onNew:()->Unit, onOpen:(Report)->Unit, onStatus:(Report,String)->Unit, onDelete:(Report)->Unit) {
    val filtered=reports.filter { (query.isBlank() || listOf(it.person,it.department,it.software,it.problem,it.id.toString(),reportCode(it.id)).any{v->v.contains(query,true)}) && (filter=="Todos" || it.status==filter) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp), contentPadding=PaddingValues(top=20.dp,bottom=24.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Gestión", "Reportes", "Busca, filtra y da seguimiento a cada caso.") }
        item { OutlinedTextField(query,onQuery,Modifier.fillMaxWidth(),placeholder={Text("Buscar por software, persona, ID…")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(16.dp),colors=fieldColors()) }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(7.dp)) { listOf("Todos","Pendiente","En proceso","Resuelta").forEach { f -> FilterChip(selected=filter==f,onClick={onFilter(f)},label={Text(f)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Color(0xFF17394A),selectedLabelColor=Cyan)) } } }
        item { Row(verticalAlignment=Alignment.CenterVertically) { Text("${filtered.size} reportes", color=Muted); Spacer(Modifier.weight(1f)); Button(onClick=onNew, colors=ButtonDefaults.buttonColors(containerColor=Cyan,contentColor=Navy),shape=RoundedCornerShape(12.dp)) { Icon(Icons.Default.Add,null); Text("Nuevo") } } }
        if(filtered.isEmpty()) item { EmptyState("No hay coincidencias", "Prueba otra búsqueda o registra una incidencia.", Icons.Default.SearchOff) }
        items(filtered,key={it.id}) { r -> Column { ReportRow(r, onClick={onOpen(r)}); Spacer(Modifier.height(7.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End, verticalAlignment=Alignment.CenterVertically) { var expanded by remember(r.id) { mutableStateOf(false) }; TextButton(onClick={expanded=true}) { Icon(Icons.Default.Sync,null); Text("Cambiar estado") }; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { listOf("Pendiente","En proceso","Resuelta").forEach { s-> DropdownMenuItem(text={Text(s)},onClick={onStatus(r,s);expanded=false}) } }; TextButton(onClick={onOpen(r)}) { Icon(Icons.Default.Edit,null); Text("Editar") }; TextButton(onClick={onDelete(r)}) { Icon(Icons.Default.DeleteOutline,null,tint=Color(0xFFFF7C8C)); Text("Eliminar",color=Color(0xFFFF7C8C)) } } } }
    }
}
@Composable private fun ReportRow(r:Report,onClick:()->Unit) {
    val tint=when(r.status){"Resuelta"->Green;"En proceso"->Blue;else->Orange}
    AppCard(Modifier.clickable{onClick()}) {
        Row(verticalAlignment=Alignment.Top) { Box(Modifier.size(42.dp).background(Color(0xFF1A3046),RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center) { Icon(Icons.Default.Assignment, null, tint=Cyan) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.problem.ifBlank{r.type},fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("${r.software.ifBlank{"Sin software"}} · ${r.department.ifBlank{"Sin departamento"}}",color=Muted,style=MaterialTheme.typography.bodySmall,maxLines=1,overflow=TextOverflow.Ellipsis); Spacer(Modifier.height(8.dp)); Row(verticalAlignment=Alignment.CenterVertically) { Text(reportCode(r.id),color=Muted,style=MaterialTheme.typography.labelSmall); Spacer(Modifier.width(8.dp)); Text(r.priority.uppercase(),color=if(r.priority=="Urgente")Color(0xFFFF7C8C) else Muted,style=MaterialTheme.typography.labelSmall); Spacer(Modifier.weight(1f)); Box(Modifier.background(tint.copy(alpha=.13f),RoundedCornerShape(7.dp)).padding(horizontal=8.dp, vertical=4.dp)) { Text(r.status.uppercase(),color=tint,style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.Bold) } } } }
    }
}
@Composable private fun AnalysisScreen(reports: List<Report>) {
    var period by remember { mutableStateOf("1 mes") }
    var periodMenuExpanded by remember { mutableStateOf(false) }
    var comparePrevious by remember { mutableStateOf(true) }
    val context = LocalContext.current
    val now = System.currentTimeMillis()
    val periodOptions = listOf("Personalizado", "Día actual", "Mes actual", "Año actual", "1 mes", "2 meses", "3 meses", "6 meses", "1 año", "Todo")
    fun calendarAt(timestamp: Long) = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
    fun subtractMonths(timestamp: Long, months: Int): Long = calendarAt(timestamp).run { add(java.util.Calendar.MONTH, -months); timeInMillis }
    fun startOfDay(timestamp: Long): Long = calendarAt(timestamp).run { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0); timeInMillis }
    fun endOfDay(timestamp: Long): Long = calendarAt(timestamp).run { set(java.util.Calendar.HOUR_OF_DAY,23); set(java.util.Calendar.MINUTE,59); set(java.util.Calendar.SECOND,59); set(java.util.Calendar.MILLISECOND,999); timeInMillis }
    fun startOfMonth(timestamp: Long): Long = calendarAt(timestamp).run { set(java.util.Calendar.DAY_OF_MONTH,1); startOfDay(timeInMillis) }
    fun startOfYear(timestamp: Long): Long = calendarAt(timestamp).run { set(java.util.Calendar.MONTH,0); set(java.util.Calendar.DAY_OF_MONTH,1); startOfDay(timeInMillis) }
    var customStart by remember { mutableLongStateOf(startOfDay(subtractMonths(now, 1))) }
    var customEnd by remember { mutableLongStateOf(endOfDay(now)) }
    val periodMonths = when (period) { "1 mes" -> 1; "2 meses" -> 2; "3 meses" -> 3; "6 meses" -> 6; "1 año" -> 12; else -> 0 }
    val periodStart = when (period) {
        "Día actual" -> startOfDay(now); "Mes actual" -> startOfMonth(now); "Año actual" -> startOfYear(now)
        "Personalizado" -> startOfDay(customStart); else -> if (periodMonths > 0) subtractMonths(now, periodMonths) else Long.MIN_VALUE
    }
    val periodEnd = if (period == "Personalizado") endOfDay(customEnd) else now
    val effectiveStart = if (period == "Todo") Long.MIN_VALUE else periodStart
    val duration = (periodEnd - effectiveStart).coerceAtLeast(1L)
    val previousBounds = when (period) {
        "Día actual" -> (effectiveStart - duration) to (effectiveStart - 1L)
        "Mes actual" -> {
            val cal = calendarAt(effectiveStart); cal.add(java.util.Calendar.MONTH, -1)
            val previousMonthStart = startOfMonth(cal.timeInMillis)
            val currentDay = calendarAt(now).get(java.util.Calendar.DAY_OF_MONTH)
            val prevCal = calendarAt(previousMonthStart)
            val lastDay = prevCal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
            prevCal.set(java.util.Calendar.DAY_OF_MONTH, minOf(currentDay, lastDay))
            val previousMonthToDateEnd = minOf(endOfDay(prevCal.timeInMillis), now - (effectiveStart - previousMonthStart))
            previousMonthStart to previousMonthToDateEnd
        }
        "Año actual" -> {
            val previousYearStartCal = calendarAt(effectiveStart); previousYearStartCal.add(java.util.Calendar.YEAR, -1)
            val previousYearStart = startOfYear(previousYearStartCal.timeInMillis)
            val priorNowCal = calendarAt(now); priorNowCal.add(java.util.Calendar.YEAR, -1)
            previousYearStart to priorNowCal.timeInMillis
        }
        else -> if (period == "Todo") Long.MIN_VALUE to Long.MIN_VALUE else (effectiveStart - duration) to (effectiveStart - 1L)
    }
    val previousStart = previousBounds.first
    val previousEnd = previousBounds.second
    // Para resueltos se usa la fecha de cierre; para abiertos, la fecha de apertura.
    fun activityTimestamp(report: Report): Long = if ((report.status.equals("Resuelta", true) || report.status.equals("Resuelto", true)) && report.closedAt > 0L) report.closedAt else report.date
    val visibleReports = if (period == "Todo") reports else reports.filter { activityTimestamp(it) >= effectiveStart && activityTimestamp(it) <= periodEnd }
    val previousReports = if (period != "Todo") reports.filter { activityTimestamp(it) >= previousStart && activityTimestamp(it) <= previousEnd } else emptyList()
    val trendPattern = when { period == "Todo" || duration > 370L * 86400000L -> "yyyy"; duration <= 35L * 86400000L -> "dd/MM"; else -> "MMM yy" }
    val trendBuckets = visibleReports.groupBy { report ->
        val cal = calendarAt(activityTimestamp(report))
        when (trendPattern) {
            "dd/MM" -> { cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0) }
            "MMM yy" -> { cal.set(java.util.Calendar.DAY_OF_MONTH, 1); cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0) }
            else -> { cal.set(java.util.Calendar.MONTH, 0); cal.set(java.util.Calendar.DAY_OF_MONTH, 1); cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0) }
        }
        cal.timeInMillis
    }.entries.sortedBy { it.key }.takeLast(8).map { entry ->
        SimpleDateFormat(trendPattern, Locale.getDefault()).format(Date(entry.key)) to entry.value
    }
    val total = visibleReports.size
    val resolvedReports = visibleReports.filter { it.status.equals("Resuelta", true) || it.status.equals("Resuelto", true) }
    val pending = visibleReports.count { it.status.equals("Pendiente", true) || it.status.equals("Pendientes", true) }
    val inProgress = visibleReports.count { it.status.equals("En proceso", true) || it.status.equals("En progreso", true) }
    val resolved = resolvedReports.size
    val resolutionRate = if (total == 0) 0 else (resolved * 100f / total).toInt()
    val durations = resolvedReports.map { r ->
        if (r.closedAt > r.date) ((r.closedAt - r.date) / 60000L).toInt().coerceAtLeast(0) else r.minutes.coerceAtLeast(0)
    }
    val avgMinutes = if (durations.isEmpty()) 0 else durations.average().toInt()
    val avgHours = avgMinutes / 60
    val avgRemainder = avgMinutes % 60
    val bySoftware = visibleReports.filter { it.software.isNotBlank() && it.software != "Otro" }
        .groupingBy { it.software }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val byDepartment = visibleReports.filter { it.department.isNotBlank() }
        .groupingBy { it.department }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val byTechnician = resolvedReports.filter { it.technician.isNotBlank() }
        .groupingBy { it.technician }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val byPriority = visibleReports.filter { it.priority.isNotBlank() }
        .groupingBy { it.priority }.eachCount().entries.sortedByDescending { it.value }
    val oldestOpenHours = visibleReports.filter { !it.status.equals("Resuelta", true) && !it.status.equals("Resuelto", true) }
        .maxOfOrNull { ((now - it.date).coerceAtLeast(0L) / 3600000L) } ?: 0L

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PageHeader("Inteligencia operativa", "Análisis", "Indicadores reales calculados a partir de tus reportes.") }
        item {
            AppCard {
                Text("Período de análisis", color = Muted, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { periodMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text(when(period) { "Todo" -> "Todo el historial"; "Personalizado" -> "Rango personalizado"; "Día actual" -> "Hoy"; "Mes actual" -> "Mes actual"; "Año actual" -> "Año actual"; else -> "Últimos $period" }, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ExpandMore, null)
                    }
                    DropdownMenu(expanded = periodMenuExpanded, onDismissRequest = { periodMenuExpanded = false }) {
                        periodOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(when(option) { "Todo" -> "Todo el historial"; "Personalizado" -> "Elegir fechas…"; "Día actual" -> "Día actual"; "Mes actual" -> "Mes actual"; "Año actual" -> "Año actual"; else -> "Últimos $option" }) },
                                leadingIcon = { if (period == option) Icon(Icons.Default.Check, null, tint = Cyan) },
                                onClick = { period = option; periodMenuExpanded = false; if (option == "Todo") comparePrevious = false }
                            )
                        }
                    }
                }
                if (period == "Personalizado") {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val c = calendarAt(customStart)
                            DatePickerDialog(context, { _, y, m, d -> customStart = calendarAt(customStart).run { set(y,m,d); startOfDay(timeInMillis) }; if (customStart > customEnd) customEnd = endOfDay(customStart) }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
                        }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) { Icon(Icons.Default.CalendarToday,null,tint=Cyan); Spacer(Modifier.width(5.dp)); Text(SimpleDateFormat("dd/MM/yy",Locale.getDefault()).format(Date(customStart))) }
                        OutlinedButton(onClick = {
                            val c = calendarAt(customEnd)
                            DatePickerDialog(context, { _, y, m, d -> customEnd = calendarAt(customEnd).run { set(y,m,d); endOfDay(timeInMillis) }; if (customEnd < customStart) customStart = startOfDay(customEnd) }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
                        }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) { Icon(Icons.Default.Event,null,tint=Violet); Spacer(Modifier.width(5.dp)); Text(SimpleDateFormat("dd/MM/yy",Locale.getDefault()).format(Date(customEnd))) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (period == "Todo") "Incluye todo el historial disponible" else "Período: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(effectiveStart))} – ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(periodEnd))}", color = Muted, style = MaterialTheme.typography.bodySmall)
                if (period != "Todo") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = comparePrevious, onCheckedChange = { comparePrevious = it }, colors = CheckboxDefaults.colors(checkedColor = Cyan))
                        Column(Modifier.weight(1f)) {
                            Text("Comparar con el período anterior", color = Color.White)
                            Text("Intervalo anterior de igual duración", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Insights, null, tint = Cyan, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Vista ejecutiva", fontWeight = FontWeight.SemiBold)
                        Text("${visibleReports.size} incidencias · ${if (period == "Todo") "historial completo" else "rango seleccionado"}", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(Modifier.background(Cyan.copy(alpha=.12f), RoundedCornerShape(10.dp)).padding(horizontal=10.dp, vertical=7.dp)) {
                        Text("$resolutionRate% resuelto", color = Cyan, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Distribución del trabajo", color = Muted, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                if (total == 0) Text("Sin datos para visualizar en este período.", color = Muted)
                else {
                    Row(Modifier.fillMaxWidth().height(12.dp).background(Color(0xFF25374B), CircleShape)) {
                        if (resolved > 0) Box(Modifier.weight(resolved.toFloat()).fillMaxHeight().background(Green))
                        if (inProgress > 0) Box(Modifier.weight(inProgress.toFloat()).fillMaxHeight().background(Blue))
                        if (pending > 0) Box(Modifier.weight(pending.toFloat()).fillMaxHeight().background(Orange))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("● Resueltos $resolved", color=Green, style=MaterialTheme.typography.labelSmall)
                        Text("● En proceso $inProgress", color=Blue, style=MaterialTheme.typography.labelSmall)
                        Text("● Pendientes $pending", color=Orange, style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        if (period != "Todo" && comparePrevious) {
            val previousResolved = previousReports.count { it.status.equals("Resuelta", true) || it.status.equals("Resuelto", true) }
            val currentDelta = total - previousReports.size
            val resolvedDelta = resolved - previousResolved
            item {
                AppCard {
                    SectionTitle("Comparación con el período anterior")
                    Text("Actual: ${visibleReports.size} reportes · Comparación: ${previousReports.size} reportes", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text(when (period) {
                        "Día actual" -> "Hoy frente al mismo tramo horario de ayer"
                        "Mes actual" -> "Mes actual frente al mismo tramo del mes anterior"
                        "Año actual" -> "Año actual frente al mismo tramo del año anterior"
                        else -> "Rango anterior de duración equivalente"
                    }, color = Muted, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Variación de reportes", color = Muted, style = MaterialTheme.typography.labelSmall)
                            Text(deltaLabel(currentDelta), color = if (currentDelta > 0) Orange else if (currentDelta < 0) Green else Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(percentDelta(visibleReports.size, previousReports.size), color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Variación de resueltos", color = Muted, style = MaterialTheme.typography.labelSmall)
                            Text(deltaLabel(resolvedDelta), color = if (resolvedDelta > 0) Green else if (resolvedDelta < 0) Orange else Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(percentDelta(resolved, previousResolved), color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text("Los reportes resueltos se agrupan por fecha de cierre; los que siguen abiertos, por fecha de apertura.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Reportes", total.toString(), Icons.Default.Dataset, Cyan, Modifier.weight(1f))
                StatCard("Resueltos", resolved.toString(), Icons.Default.CheckCircle, Green, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Pendientes", pending.toString(), Icons.Default.Schedule, Orange, Modifier.weight(1f))
                StatCard("En proceso", inProgress.toString(), Icons.Default.Autorenew, Blue, Modifier.weight(1f))
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Cyan.copy(alpha = .12f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Speed, null, tint = Cyan, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text("TIEMPO MEDIO DE RESOLUCIÓN", color = Muted, style = MaterialTheme.typography.labelSmall)
                        Text(if (durations.isEmpty()) "—" else if (avgHours > 0) "${avgHours} h ${avgRemainder} min" else "$avgMinutes min", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Calculado desde la apertura hasta el cierre", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tasa de resolución", color = Muted, modifier = Modifier.weight(1f))
                    Text("$resolutionRate%", color = Green, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                Box(Modifier.fillMaxWidth().height(9.dp).background(Color(0xFF25374B), CircleShape)) {
                    Box(Modifier.fillMaxWidth(resolutionRate / 100f).fillMaxHeight().background(Brush.horizontalGradient(listOf(Cyan, Green)), CircleShape))
                }
                Spacer(Modifier.height(8.dp))
                Text("${resolved} de ${total} reportes resueltos en el período seleccionado", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            AppCard {
                SectionTitle("Evolución de incidencias")
                Text("Actividad agrupada según el rango seleccionado", color=Muted, style=MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(14.dp))
                if (trendBuckets.isEmpty()) Text("El gráfico aparecerá cuando existan reportes en este período.", color=Muted)
                else {
                    val maxBucket = (trendBuckets.maxOfOrNull { it.second.size } ?: 1).coerceAtLeast(1)
                    Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement=Arrangement.spacedBy(7.dp), verticalAlignment=Alignment.Bottom) {
                        trendBuckets.forEach { bucket ->
                            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Bottom) {
                                Text(bucket.second.size.toString(), color=Cyan, style=MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.height(5.dp))
                                Box(Modifier.fillMaxWidth(.72f).height((78f * bucket.second.size / maxBucket).coerceAtLeast(5f).dp).background(Brush.verticalGradient(listOf(Cyan, Blue)), RoundedCornerShape(topStart=6.dp, topEnd=6.dp)))
                                Spacer(Modifier.height(7.dp))
                                Text(bucket.first, color=Muted, style=MaterialTheme.typography.labelSmall, maxLines=1, overflow=TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                SectionTitle("Estado de los reportes")
                Spacer(Modifier.height(12.dp))
                if (total == 0) Text("No hay reportes en este período.", color = Muted)
                else {
                    BarLine("Resueltos", resolved, total, Green)
                    BarLine("En proceso", inProgress, total, Blue)
                    BarLine("Pendientes", pending, total, Orange)
                }
            }
        }
        item {
            AppCard {
                SectionTitle("Incidencias por departamento")
                Spacer(Modifier.height(12.dp))
                if (byDepartment.isEmpty()) Text("Completa el departamento o unidad comercial en los reportes para ver dónde se concentran las incidencias.", color = Muted)
                else byDepartment.forEach { (name, count) -> BarLine(name, count, total, Cyan) }
            }
        }
        item {
            AppCard {
                SectionTitle("Incidencias por software o equipo")
                Spacer(Modifier.height(12.dp))
                if (bySoftware.isEmpty()) Text("Aún no hay datos de software o equipo suficientes.", color = Muted)
                else bySoftware.forEach { (name, count) -> BarLine(name, count, total, Violet) }
            }
        }
        item {
            AppCard {
                SectionTitle("Carga por prioridad")
                Spacer(Modifier.height(12.dp))
                if (byPriority.isEmpty()) Text("No hay prioridades registradas.", color = Muted)
                else byPriority.forEach { (name, count) -> BarLine(name, count, total, if (name.equals("Urgente", true) || name.equals("Alta", true)) Color(0xFFFF7C8C) else Orange) }
            }
        }
        item {
            AppCard {
                SectionTitle("Resoluciones por técnico")
                Spacer(Modifier.height(5.dp))
                Text("Cantidad de reportes cerrados por cada técnico en el período.", color = Muted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                if (byTechnician.isEmpty()) Text("Los resultados aparecerán cuando haya reportes resueltos con técnico responsable asignado.", color = Muted)
                else byTechnician.forEach { (name, count) -> BarLine(name, count, (byTechnician.maxOfOrNull { it.value } ?: 1).coerceAtLeast(1), Green) }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Lightbulb, null, tint = Orange, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Lectura de los datos", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text(when {
                            total == 0 -> "No hay reportes en el período seleccionado. Cambia el filtro o registra una incidencia para comenzar el análisis."
                            resolved == 0 -> "Todavía no hay reportes cerrados en este período. Al resolverlos se calculará el tiempo medio de solución."
                            pending + inProgress > 0 -> "Se ha resuelto el $resolutionRate% de los reportes. Hay ${pending + inProgress} casos abiertos; el más antiguo lleva aproximadamente ${oldestOpenHours} horas sin cerrar. Prioriza los casos urgentes y los de mayor antigüedad."
                            byDepartment.isNotEmpty() -> "Todos los reportes del período están resueltos. El departamento con más incidencias es ${byDepartment.first().key} (${byDepartment.first().value})."
                            else -> "Todos los reportes del período están resueltos. Continúa registrando departamento y técnico para obtener comparativas más completas."
                        }, color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item { Text("Nota: las estadísticas usan los datos guardados localmente en este teléfono. El tiempo medio se calcula solo con reportes resueltos.", color = Muted, style = MaterialTheme.typography.bodySmall) }
    }
}
private fun deltaLabel(value: Int): String = when { value > 0 -> "+$value"; else -> value.toString() }
private fun percentDelta(current: Int, previous: Int): String = when {
    previous == 0 && current == 0 -> "0% frente al período anterior"
    previous == 0 -> "Nuevo: sin registros en el período anterior"
    else -> {
        val pct = ((current - previous) * 100.0 / previous)
        val formatted = String.format(Locale.getDefault(), "%.1f", kotlin.math.abs(pct))
        val sign = if (pct > 0) "+" else if (pct < 0) "−" else ""
        "$sign$formatted% frente al período anterior"
    }
}

@Composable private fun BarLine(label:String,count:Int,total:Int,color:Color) { Column(Modifier.padding(bottom=12.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text(label,Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis); Text(count.toString(),color=color,fontWeight=FontWeight.Bold) }; Spacer(Modifier.height(6.dp)); Box(Modifier.fillMaxWidth().height(7.dp).background(Color(0xFF25374B),CircleShape)) { Box(Modifier.fillMaxWidth(if(total==0)0f else (count.toFloat()/total).coerceIn(.02f,1f)).fillMaxHeight().background(color,CircleShape)) } } }

@Composable private fun ExportScreen(reports: List<Report>, onExport: (List<Report>, String) -> Unit) {
    var kind by remember { mutableStateOf("Informe ejecutivo") }
    var period by remember { mutableStateOf("Todos los registros") }
    var format by remember { mutableStateOf("PDF") }
    var kindExpanded by remember { mutableStateOf(false) }
    var periodExpanded by remember { mutableStateOf(false) }
    var formatExpanded by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    val matchingReports = reports.filter { r ->
        val timestamp = if ((r.status.equals("Resuelta", true) || r.status.equals("Resuelto", true)) && r.closedAt > 0) r.closedAt else r.date
        val inPeriod = when(period) {
            "Últimos 7 días" -> timestamp in (now - 7L * 86400000L)..now
            "Últimos 30 días" -> timestamp in (now - 30L * 86400000L)..now
            "Este año" -> SimpleDateFormat("yyyy", Locale.getDefault()).format(Date(timestamp)) == SimpleDateFormat("yyyy", Locale.getDefault()).format(Date(now))
            else -> true
        }
        inPeriod && when(kind) {
            "Incidencias abiertas" -> !r.status.equals("Resuelta", true) && !r.status.equals("Resuelto", true)
            "Incidencias resueltas" -> r.status.equals("Resuelta", true) || r.status.equals("Resuelto", true)
            "Casos urgentes" -> r.priority.equals("Urgente", true) || r.priority.equals("Alta", true)
            "Por departamento" -> r.department.isNotBlank()
            "Por técnico" -> r.technician.isNotBlank()
            "Por software o equipo" -> r.software.isNotBlank()
            else -> true
        }
    }
    // Grouped report types are sorted by their selected dimension; other reports stay newest-first.
    val filtered = when (kind) {
        "Por departamento" -> matchingReports.sortedWith(compareBy<Report> { it.department.lowercase(Locale.ROOT) }.thenByDescending { it.date })
        "Por técnico" -> matchingReports.sortedWith(compareBy<Report> { it.technician.lowercase(Locale.ROOT) }.thenByDescending { it.date })
        "Por software o equipo" -> matchingReports.sortedWith(compareBy<Report> { it.software.lowercase(Locale.ROOT) }.thenByDescending { it.date })
        "Incidencias abiertas" -> matchingReports.sortedWith(compareBy<Report> { it.priority.lowercase(Locale.ROOT) }.thenBy { it.date })
        "Casos urgentes" -> matchingReports.sortedWith(compareBy<Report> { if (it.priority.equals("Urgente", true)) 0 else 1 }.thenByDescending { it.date })
        else -> matchingReports.sortedByDescending { it.date }
    }
    val resolved = filtered.count { it.status.equals("Resuelta", true) || it.status.equals("Resuelto", true) }
    val open = filtered.size - resolved
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp), contentPadding=PaddingValues(top=20.dp,bottom=28.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { PageHeader("Centro de documentación", "Informes profesionales", "Genera informes a medida, filtra la información y expórtala en el formato que necesitas.") }
        item { AppCard {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).background(Brush.linearGradient(listOf(Cyan,Blue)),RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center) { Icon(Icons.Default.Assessment,null,tint=Navy,modifier=Modifier.size(29.dp)) }
                Spacer(Modifier.width(13.dp)); Column { Text("Generador de informes",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold); Text("NEXORA · INFORMACIÓN OPERATIVA",color=Cyan,style=MaterialTheme.typography.labelSmall) }
            }
            Spacer(Modifier.height(18.dp)); Text("TIPO DE INFORME",color=Muted,style=MaterialTheme.typography.labelMedium)
            Box { OutlinedButton(onClick={kindExpanded=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp)) { Text(kind,Modifier.weight(1f),textAlign=TextAlign.Start); Icon(Icons.Default.ExpandMore,null) }; DropdownMenu(expanded=kindExpanded,onDismissRequest={kindExpanded=false}) { listOf("Informe ejecutivo","Incidencias abiertas","Incidencias resueltas","Casos urgentes","Por departamento","Por técnico","Por software o equipo").forEach { DropdownMenuItem(text={Text(it)},onClick={kind=it;kindExpanded=false}) } } }
            Spacer(Modifier.height(12.dp)); Text("PERÍODO DE LOS DATOS",color=Muted,style=MaterialTheme.typography.labelMedium)
            Box { OutlinedButton(onClick={periodExpanded=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp)) { Icon(Icons.Default.CalendarMonth,null); Spacer(Modifier.width(8.dp)); Text(period,Modifier.weight(1f),textAlign=TextAlign.Start); Icon(Icons.Default.ExpandMore,null) }; DropdownMenu(expanded=periodExpanded,onDismissRequest={periodExpanded=false}) { listOf("Todos los registros","Últimos 7 días","Últimos 30 días","Este año").forEach { DropdownMenuItem(text={Text(it)},onClick={period=it;periodExpanded=false}) } } }
            Spacer(Modifier.height(12.dp)); Text("FORMATO DE EXPORTACIÓN",color=Muted,style=MaterialTheme.typography.labelMedium)
            Box { OutlinedButton(onClick={formatExpanded=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp)) { Icon(when(format){"PDF"->Icons.Default.PictureAsPdf;"CSV / Excel"->Icons.Default.TableChart;"HTML"->Icons.Default.Language;"TXT"->Icons.Default.Description;else->Icons.Default.DataObject},null,tint=Cyan); Spacer(Modifier.width(8.dp)); Text(format,Modifier.weight(1f),textAlign=TextAlign.Start); Icon(Icons.Default.ExpandMore,null) }; DropdownMenu(expanded=formatExpanded,onDismissRequest={formatExpanded=false}) { listOf("PDF","CSV / Excel","HTML","TXT","JSON").forEach { DropdownMenuItem(text={Text(it)},leadingIcon={Icon(when(it){"PDF"->Icons.Default.PictureAsPdf;"CSV / Excel"->Icons.Default.TableChart;"HTML"->Icons.Default.Language;"TXT"->Icons.Default.Description;else->Icons.Default.DataObject},null)},onClick={format=it;formatExpanded=false}) } } }
            Spacer(Modifier.height(18.dp)); Button(onClick={onExport(filtered,format)},enabled=filtered.isNotEmpty(),modifier=Modifier.fillMaxWidth().height(52.dp),colors=ButtonDefaults.buttonColors(containerColor=Cyan,contentColor=Navy),shape=RoundedCornerShape(14.dp)) { Icon(Icons.Default.FileDownload,null); Spacer(Modifier.width(9.dp)); Text("Generar y exportar informe",fontWeight=FontWeight.Bold) }
            if(filtered.isEmpty()) { Spacer(Modifier.height(8.dp)); Text("No hay registros para esta combinación. Cambia el tipo o el período.",color=Orange,style=MaterialTheme.typography.bodySmall) }
        } }
        item { Text("VISTA PREVIA DEL CONTENIDO",color=Cyan,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold) }
        item { AppCard {
            Text(kind,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold); Text("Período: $period",color=Muted,style=MaterialTheme.typography.bodySmall); Text("Generado: ${SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Date())}",color=Muted,style=MaterialTheme.typography.bodySmall)
            Divider(color=Color(0xFF26374A),modifier=Modifier.padding(vertical=12.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { StatCard("Incluidos",filtered.size.toString(),Icons.Default.Dataset,Cyan,Modifier.weight(1f)); StatCard("Abiertos",open.toString(),Icons.Default.Schedule,Orange,Modifier.weight(1f)); StatCard("Resueltos",resolved.toString(),Icons.Default.CheckCircle,Green,Modifier.weight(1f)) }
            Spacer(Modifier.height(12.dp)); SummaryLine("Tasa de resolución",if(filtered.isEmpty()) "—" else "${resolved*100/filtered.size}%")
            SummaryLine("Casos urgentes",filtered.count{it.priority.equals("Urgente",true)||it.priority.equals("Alta",true)}.toString())
            SummaryLine("Departamentos identificados",filtered.map{it.department}.filter{it.isNotBlank()}.distinct().size.toString())
            SummaryLine("Técnicos identificados",filtered.map{it.technician}.filter{it.isNotBlank()}.distinct().size.toString())
            Spacer(Modifier.height(8.dp)); Text("El documento incluye el detalle de las incidencias filtradas y sus campos disponibles. Los datos ausentes se mantienen vacíos; no se generan cifras ficticias.",color=Muted,style=MaterialTheme.typography.bodySmall)
        } }
        item { AppCard { SectionTitle("Formatos disponibles"); Spacer(Modifier.height(8.dp)); SummaryLine("PDF","Documento listo para compartir o imprimir"); SummaryLine("CSV / Excel","Tabla editable en hojas de cálculo"); SummaryLine("HTML","Informe con estilo que puede imprimirse como PDF"); SummaryLine("TXT","Resumen de texto ligero"); SummaryLine("JSON","Datos estructurados para respaldo o integración") } }
    }
}

private fun reportToText(reports: List<Report>): String = buildString {
    appendLine("NEXORA | INFORME DE ACTIVIDAD"); appendLine("Generado: ${SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Date())}")
    appendLine("Total: ${reports.size} | Abiertos: ${reports.count{!it.status.equals("Resuelta",true)&&!it.status.equals("Resuelto",true)}} | Resueltos: ${reports.count{it.status.equals("Resuelta",true)||it.status.equals("Resuelto",true)}}")
    appendLine("=".repeat(58))
    reports.forEachIndexed { i, r ->
        appendLine("${i + 1}. ${reportCode(r.id)} · ${r.problem.ifBlank { r.type }}")
        appendLine("Apertura: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(r.date))} | Cierre: ${if (r.closedAt > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(r.closedAt)) else "Sin cerrar"}")
        appendLine("Estado: ${r.status} | Prioridad: ${r.priority} | Tiempo registrado: ${r.minutes} min")
        appendLine("Persona: ${r.person} | Departamento: ${r.department} | Técnico: ${r.technician}")
        appendLine("Software/equipo: ${r.software} | Tipo: ${r.type}")
        appendLine("Problema: ${r.problem}")
        appendLine("Diagnóstico: ${r.diagnosis}")
        appendLine("Solución: ${r.solution}")
        appendLine("Notas: ${r.notes}")
        appendLine("-".repeat(58))
    }
}
private fun reportToHtml(reports: List<Report>): String {
    fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    fun date(ts: Long) = if (ts > 0L) SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(ts)) else "—"
    val rows = reports.joinToString("") { r ->
        "<tr><td>${esc(reportCode(r.id))}</td><td>${esc(date(r.date))}</td><td>${esc(date(r.closedAt))}</td><td>${esc(r.person)}</td><td>${esc(r.department)}</td><td>${esc(r.software)}</td><td>${esc(r.type)}</td><td>${esc(r.priority)}</td><td>${esc(r.status)}</td><td>${r.minutes}</td><td>${esc(r.technician)}</td><td>${esc(r.problem)}</td><td>${esc(r.diagnosis)}</td><td>${esc(r.solution)}</td><td>${esc(r.notes)}</td></tr>"
    }
    val resolved = reports.count { it.status.equals("Resuelta", true) || it.status.equals("Resuelto", true) }
    val open = reports.size - resolved
    return """<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Informe Nexora</title><style>
body{font-family:Arial,sans-serif;color:#142238;margin:24px}header{background:#10243b;color:white;padding:22px;border-radius:12px}header h1{margin:0;color:#48dDF5}.kpis{display:flex;gap:12px;margin:18px 0}.kpi{padding:12px;background:#edf5fa;border-radius:8px;flex:1}table{width:100%;border-collapse:collapse;font-size:9px}th{background:#173b5c;color:white;text-align:left}td,th{padding:5px;border:1px solid #d6e0e8;vertical-align:top;overflow-wrap:anywhere}tr:nth-child(even){background:#f3f7fa}.note{color:#617286;font-size:11px}@page{size:landscape;margin:8mm}@media print{body{margin:0}header{print-color-adjust:exact;-webkit-print-color-adjust:exact}}
</style></head><body><header><h1>NEXORA</h1><h2>Informe de actividad y seguimiento</h2><p>Generado ${esc(date(System.currentTimeMillis()))}</p></header><div class="kpis"><div class="kpi"><b>Total de casos</b><h2>${reports.size}</h2></div><div class="kpi"><b>Abiertos</b><h2>$open</h2></div><div class="kpi"><b>Resueltos</b><h2>$resolved</h2></div></div><table><thead><tr><th>Código</th><th>Apertura</th><th>Cierre</th><th>Persona</th><th>Departamento</th><th>Software/equipo</th><th>Tipo</th><th>Prioridad</th><th>Estado</th><th>Minutos</th><th>Técnico</th><th>Problema</th><th>Diagnóstico</th><th>Solución</th><th>Notas</th></tr></thead><tbody>$rows</tbody></table><p class="note">Informe generado con los datos disponibles en Nexora. Los campos no registrados se mantienen vacíos.</p></body></html>"""
}
private fun reportToPdf(reports: List<Report>): ByteArray {
    val doc=android.graphics.pdf.PdfDocument(); val pageWidth=595; val pageHeight=842; val margin=36f
    val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val lines=reportToText(reports).lines().flatMap { line -> if(line.length>86) line.chunked(86) else listOf(line) }
    var pageNum=1; var page:android.graphics.pdf.PdfDocument.Page?=null; var canvas:android.graphics.Canvas?=null; var y=0f
    fun startPage() { val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNum++).create(); page=doc.startPage(info); canvas=page!!.canvas; y=margin; paint.color=android.graphics.Color.rgb(16,36,59); paint.textSize=17f; paint.typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD); canvas!!.drawText("NEXORA · INFORME DE ACTIVIDAD",margin,y,paint); y+=24; paint.textSize=9f; paint.typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL); paint.color=android.graphics.Color.DKGRAY }
    startPage()
    lines.forEach { line -> if(y>pageHeight-margin){doc.finishPage(page!!);startPage()}; canvas!!.drawText(line.take(100),margin,y,paint); y+=13f }
    doc.finishPage(page!!); val out=java.io.ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray()
}
@Composable private fun SummaryLine(label:String,value:String) { Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween) { Text(label,color=Muted); Text(value,fontWeight=FontWeight.SemiBold) } }
private fun csvEscape(value: String): String = "\"${value.replace("\"", "\"\"").replace("\r", " ").replace("\n", " ")}\""
private fun reportsToCsv(reports: List<Report>): String {
    // Keep readable date plus epoch timestamps so importing does not lose historical dates.
    val header = listOf("id","fecha","fecha_epoch","cerrado_epoch","persona","departamento","software","tipo","prioridad","problema","diagnostico","solucion","minutos","estado","tecnico","notas")
    val rows = reports.map { r -> listOf(
        r.id.toString(), SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date(r.date)),
        r.date.toString(), r.closedAt.toString(), r.person, r.department, r.software, r.type,
        r.priority, r.problem, r.diagnosis, r.solution, r.minutes.toString(), r.status, r.technician, r.notes
    ) }
    return (listOf(header) + rows).joinToString("\r\n") { row -> row.joinToString(";") { csvEscape(it) } }
}
private fun csvToReports(csv: String): List<Report> {
    val lines = csv.lineSequence().filter { it.isNotBlank() }.toList()
    if (lines.size < 2) return emptyList()
    fun parse(line: String): List<String> {
        val out = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ }
                else quoted = !quoted
            } else if ((c == ';' || c == ',') && !quoted) { out.add(cell.toString()); cell.setLength(0) }
            else cell.append(c)
            i++
        }
        out.add(cell.toString()); return out
    }
    val header = parse(lines.first()).map { it.trim().lowercase(Locale.ROOT) }
    fun value(row: List<String>, name: String) = row.getOrNull(header.indexOf(name).takeIf { it >= 0 } ?: header.size).orEmpty()
    fun timestamp(row: List<String>): Long {
        value(row, "fecha_epoch").toLongOrNull()?.takeIf { it > 0L }?.let { return it }
        val readable = value(row, "fecha")
        return runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).parse(readable)?.time }.getOrNull()
            ?: runCatching { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).parse(readable)?.time }.getOrNull()
            ?: System.currentTimeMillis()
    }
    return lines.drop(1).mapNotNull { line ->
        runCatching {
            val r = parse(line)
            val id = value(r, "id").toLongOrNull()?.takeIf { it > 0L } ?: System.currentTimeMillis()
            Report(
                id = id, person = value(r, "persona"), department = value(r, "departamento"),
                software = value(r, "software"), type = value(r, "tipo"),
                priority = value(r, "prioridad").ifBlank { "Normal" }, problem = value(r, "problema"),
                diagnosis = value(r, "diagnostico"), solution = value(r, "solucion"),
                minutes = value(r, "minutos").toIntOrNull() ?: 0,
                status = value(r, "estado").ifBlank { "Pendiente" }, date = timestamp(r),
                technician = value(r, "tecnico"), notes = value(r, "notas"),
                closedAt = value(r, "cerrado_epoch").toLongOrNull()?.coerceAtLeast(0L) ?: 0L
            )
        }.getOrNull()
    }.filter { it.person.isNotBlank() || it.problem.isNotBlank() }
}

@Composable private fun SettingsScreen(count:Int,onExportCsv:()->Unit,onExportBackup:()->Unit,onImportBackup:()->Unit,onImportCsv:()->Unit,onClear:()->Unit) {
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp),contentPadding=PaddingValues(top=20.dp,bottom=24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { PageHeader("Centro de control", "Configuración", "Administra tus datos, copias de seguridad y preferencias.") }
        item { AppCard { Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Cyan,Blue)),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center) { Icon(Icons.Default.Storage,null,tint=Navy,modifier=Modifier.size(27.dp)) }; Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("Base de datos local",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium); Text("$count reportes en este dispositivo",color=Muted,style=MaterialTheme.typography.bodySmall); Text("Los datos permanecen en tu teléfono hasta que los exportes.",color=Muted,style=MaterialTheme.typography.bodySmall) } } } }
        item { Text("COPIAS DE SEGURIDAD",color=Cyan,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold) }
        item { AppCard { SettingsAction(Icons.Default.Backup,"Exportar copia completa","JSON · conserva todos los campos para restaurar",onExportBackup); Divider(color=Color(0xFF26374A)); SettingsAction(Icons.Default.Restore,"Importar / restaurar copia","Recupera una copia JSON exportada por la app",onImportBackup) } }
        item { Text("EXCEL Y HOJAS DE CÁLCULO",color=Cyan,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold) }
        item { AppCard { SettingsAction(Icons.Default.TableView,"Exportar para Excel","CSV UTF-8 con separador compatible con Excel",onExportCsv); Divider(color=Color(0xFF26374A)); SettingsAction(Icons.Default.FileOpen,"Importar desde CSV","Añade reportes desde un CSV con columnas exportadas por la app",onImportCsv); Spacer(Modifier.height(6.dp)); Text("Consejo: para Excel, abre el CSV usando UTF-8. La importación espera las columnas generadas por Nexora.",color=Muted,style=MaterialTheme.typography.bodySmall) } }
        item { AppCard {
            SectionTitle("Recordatorios automáticos")
            Spacer(Modifier.height(8.dp))
            Text("Nexora envía avisos al teléfono para revisar los reportes.", color = Color.White)
            Spacer(Modifier.height(4.dp))
            Text("Lunes a sábado · 8:30 a. m. a 4:30 p. m. · cada 2 horas.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Text("En Android 13 o posterior, permite las notificaciones cuando el sistema lo solicite. El ahorro de batería puede retrasar la ejecución.", color = Muted, style = MaterialTheme.typography.bodySmall)
        } }
        item { AppCard { SectionTitle("Acerca de la aplicación"); Spacer(Modifier.height(8.dp)); Text("NEXORA",fontWeight=FontWeight.SemiBold); Text("Versión 2.0 Beta 12 · Cada incidencia bajo control",color=Muted,style=MaterialTheme.typography.bodySmall) } }
        item { AppCard { Text("Zona de mantenimiento",color=Color(0xFFFF8796),fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(5.dp)); Text("Eliminar todos los registros es irreversible. Exporta una copia antes de continuar.",color=Muted,style=MaterialTheme.typography.bodySmall); Spacer(Modifier.height(12.dp)); OutlinedButton(onClick={confirm=true},colors=ButtonDefaults.outlinedButtonColors(contentColor=Color(0xFFFF8796)),modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteForever,null); Spacer(Modifier.width(8.dp)); Text("Borrar todos los reportes") } } }
    }
    if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("¿Eliminar todos los reportes?")},text={Text("Esta acción no se puede deshacer.")},confirmButton={TextButton(onClick={onClear();confirm=false}){Text("Eliminar",color=Color(0xFFFF8796))}},dismissButton={TextButton(onClick={confirm=false}){Text("Cancelar")}})
}
@Composable private fun SettingsAction(icon:ImageVector,title:String,subtitle:String,onClick:()->Unit) { Row(Modifier.fillMaxWidth().clickable{onClick()}.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Cyan); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.Medium); Text(subtitle,color=Muted,style=MaterialTheme.typography.bodySmall) }; Icon(Icons.Default.ChevronRight,null,tint=Muted) } }

@Composable private fun ReportForm(existing: Report?, onDismiss: () -> Unit, onSave: (Report) -> Unit) {
    val draftId = remember(existing?.id) { existing?.id ?: System.currentTimeMillis() }
    var person by remember { mutableStateOf(existing?.person.orEmpty()) }
    var department by remember { mutableStateOf(existing?.department.orEmpty()) }
    val softwareTypes = listOf("Windows", "Microsoft Office", "Golden", "Mercurio", "SQL", "Antivirus", "Navegador", "Impresora", "Otro")
    val initialSoftware = existing?.software.orEmpty()
    var software by remember { mutableStateOf(when { existing == null -> "Windows"; initialSoftware in softwareTypes -> initialSoftware; initialSoftware.isBlank() -> ""; else -> "Otro" }) }
    var customSoftware by remember { mutableStateOf(if (initialSoftware.isNotBlank() && initialSoftware !in softwareTypes) initialSoftware else "") }
    var type by remember { mutableStateOf(existing?.type ?: "Instalación") }
    var customType by remember { mutableStateOf(existing?.type?.takeUnless { it in listOf("Instalación", "Revisión", "Solución", "Mantenimiento", "Redes", "Hardware", "Otro") }.orEmpty()) }
    var priority by remember { mutableStateOf(existing?.priority ?: "Normal") }
    var problem by remember { mutableStateOf(existing?.problem.orEmpty()) }
    var diagnosis by remember { mutableStateOf(existing?.diagnosis.orEmpty()) }
    var solution by remember { mutableStateOf(existing?.solution.orEmpty()) }
    var technician by remember { mutableStateOf(existing?.technician.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var minutes by remember { mutableStateOf(existing?.minutes?.toString() ?: "0") }
    var status by remember { mutableStateOf(existing?.status ?: "Pendiente") }
    var error by remember { mutableStateOf(false) }
    var showWorkDialog by remember { mutableStateOf(false) }
    var softwareExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }
    var advancedExpanded by remember { mutableStateOf(false) }
    val workTypes = listOf("Instalación", "Revisión", "Solución", "Mantenimiento", "Redes", "Hardware", "Otro")
    val dateText = remember(existing?.date) { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(existing?.date ?: System.currentTimeMillis())) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Navy,
            shape = RoundedCornerShape(0.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().background(Brush.horizontalGradient(listOf(Color(0xFF0C2947), Color(0xFF10243C)))).padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (existing == null) "Nuevo Reporte" else "Editar Reporte", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("NEXORA · SOPORTE TÉCNICO", color = Cyan, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.sp)
                    }
                    Icon(Icons.Default.Assignment, null, tint = Cyan, modifier = Modifier.size(26.dp))
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(4.dp, 24.dp).background(Cyan, RoundedCornerShape(4.dp)))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Información general", color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                            Text("Datos principales de la incidencia", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    FormFieldLabel("ID del reporte · generado automáticamente")
                    Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Fingerprint, null, tint = Cyan)
                        Spacer(Modifier.width(12.dp))
                        Text(reportCode(draftId), color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(if (existing == null) "NUEVO" else "REGISTRO", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    FormFieldLabel("Fecha de apertura")
                    Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Cyan)
                        Spacer(Modifier.width(12.dp))
                        Text(dateText, color = Color.White, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.weight(1f))
                        Text(if (existing == null) "HOY" else "REGISTRADA", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    FormFieldLabel("Software / equipo")
                    Box {
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).clickable { softwareExpanded = true }.padding(horizontal = 16.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Computer, null, tint = Cyan)
                            Spacer(Modifier.width(12.dp))
                            Text(if (software == "Otro" && customSoftware.isNotBlank()) customSoftware else software.ifBlank { "Seleccionar software o equipo" }, color = if (software.isBlank()) Muted else Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Icon(Icons.Default.ExpandMore, null, tint = Muted)
                        }
                        DropdownMenu(expanded = softwareExpanded, onDismissRequest = { softwareExpanded = false }, modifier = Modifier.background(Panel)) {
                            softwareTypes.forEach { option -> DropdownMenuItem(text = { Text(option, color = Color.White) }, onClick = { software = option; softwareExpanded = false }) }
                        }
                    }
                    if (software == "Otro") {
                        OutlinedTextField(
                            value = customSoftware,
                            onValueChange = { customSoftware = it.take(80); error = false },
                            label = { Text("Especifica software o equipo") },
                            placeholder = { Text("Ej. Ubuntu Server, escáner…") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            shape = RoundedCornerShape(12.dp), colors = fieldColors()
                        )
                        if (error && customSoftware.isBlank()) {
                            Text("Este campo es obligatorio cuando seleccionas Otro.", color = Color(0xFFFF8796), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF213A55))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EditNote, null, tint = Cyan)
                                Spacer(Modifier.width(8.dp))
                                Text("Descripción del problema o tarea", color = Color.White, fontWeight = FontWeight.SemiBold)
                            }
                            OutlinedTextField(
                                value = problem,
                                onValueChange = { problem = it.take(500); error = false },
                                placeholder = { Text("Escribe aquí la descripción…", color = Muted) },
                                modifier = Modifier.fillMaxWidth(), minLines = 4, maxLines = 6,
                                shape = RoundedCornerShape(12.dp), colors = fieldColors()
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                if (error && problem.isBlank()) Text("La descripción es obligatoria", color = Color(0xFFFF8796), style = MaterialTheme.typography.labelSmall)
                                else Text("Describe el error, solicitud o trabajo realizado", color = Muted, style = MaterialTheme.typography.labelSmall)
                                Text("${problem.length}/500", color = if (problem.length >= 480) Orange else Muted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    FormFieldLabel("Estado")
                    Box {
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).clickable { statusExpanded = true }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(when (status) { "Resuelta", "Resuelto" -> Green; "En proceso" -> Cyan; else -> Orange }, CircleShape))
                            Spacer(Modifier.width(12.dp))
                            Text(status, color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Icon(Icons.Default.ExpandMore, null, tint = Muted)
                        }
                        DropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }, modifier = Modifier.background(Panel)) {
                            listOf("Pendiente", "En proceso", "Resuelta").forEach { option -> DropdownMenuItem(text = { Text(option, color = Color.White) }, onClick = { status = option; statusExpanded = false }) }
                        }
                    }
                    OutlinedTextField(person, { person = it }, label = { Text("Persona / usuario (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = fieldColors())
                    OutlinedTextField(department, { department = it }, label = { Text("Departamento o Unidad Comercial") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = fieldColors(), leadingIcon = { Icon(Icons.Default.Business, null) })
                    FormFieldLabel("Técnico responsable")
                    var technicianExpanded by remember { mutableStateOf(false) }
                    Box {
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(14.dp)).clickable { technicianExpanded = true }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Engineering, null, tint = Cyan)
                            Spacer(Modifier.width(12.dp))
                            Text(technician.ifBlank { "Seleccionar técnico" }, color = if (technician.isBlank()) Muted else Color.White, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ExpandMore, null, tint = Muted)
                        }
                        DropdownMenu(expanded = technicianExpanded, onDismissRequest = { technicianExpanded = false }, modifier = Modifier.background(Panel)) {
                            listOf("Yasel", "Getma", "Naybet", "Yanelis", "Selene").forEach { name ->
                                DropdownMenuItem(text = { Text(name, color = Color.White) }, onClick = { technician = name; technicianExpanded = false })
                            }
                        }
                    }
                    FormFieldLabel("Prioridad")
                    ChoiceChips(listOf("Baja", "Normal", "Alta", "Urgente"), priority) { priority = it }
                    OutlinedTextField(diagnosis, { diagnosis = it }, label = { Text("Diagnóstico") }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(12.dp), colors = fieldColors(), leadingIcon = { Icon(Icons.Default.ManageSearch, null) })
                    OutlinedTextField(notes, { notes = it }, label = { Text("Observaciones") }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(12.dp), colors = fieldColors(), leadingIcon = { Icon(Icons.Default.Notes, null) })
                    if (existing != null) {
                        val elapsed = if (existing.status == "Resuelta" && existing.closedAt > 0L) ((existing.closedAt-existing.date).coerceAtLeast(0L)/60000L).toInt() else ((System.currentTimeMillis()-existing.date).coerceAtLeast(0L)/60000L).toInt()
                        Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Timer, null, tint = Cyan)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Tiempo transcurrido", color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text(if (existing.status == "Resuelta") "Tiempo total hasta el cierre" else "Se calculará automáticamente al cerrar el reporte", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                                Spacer(Modifier.weight(1f))
                                Text(formatDuration(elapsed), color = Cyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Surface(modifier = Modifier.fillMaxWidth().imePadding(), color = Color(0xFF081727), shadowElevation = 12.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(0.85f).heightIn(min = 48.dp, max = 54.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B4560))) {
                            Text("Cancelar", fontWeight = FontWeight.SemiBold)
                        }
                        Button(
                            onClick = {
                                if (problem.isBlank() || (software == "Otro" && customSoftware.isBlank())) {
                                    error = true
                                } else {
                                    val finalSoftware = if (software == "Otro") customSoftware.trim() else software.trim()
                                    val now = System.currentTimeMillis()
                                    val openedAt = existing?.date ?: now
                                    val closedAt = when {
                                        status != "Resuelta" -> 0L
                                        existing?.status == "Resuelta" && (existing.closedAt > 0L) -> existing.closedAt
                                        else -> now
                                    }
                                    val elapsedMinutes = if (closedAt > 0L) ((closedAt-openedAt).coerceAtLeast(0L)/60000L).toInt() else 0
                                    onSave(Report(
                                        id = draftId, person = person.trim(), department = department.trim(),
                                        software = finalSoftware, type = "", priority = priority, problem = problem.trim(),
                                        diagnosis = diagnosis.trim(), solution = "", minutes = elapsedMinutes,
                                        status = status, date = openedAt, technician = technician.trim(), notes = notes.trim(), closedAt = closedAt
                                    ))
                                }
                            },
                            modifier = Modifier.weight(1.25f).heightIn(min = 48.dp, max = 54.dp), shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
                        ) {
                            Icon(Icons.Default.Save, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Guardar reporte", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }


}

private fun reportCode(id: Long): String {
    val stamp = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(id))
    return "NX-$stamp-${(id % 1000L).toString().padStart(3, '0')}"
}

private fun formatDuration(minutes: Int): String {
    val safe = minutes.coerceAtLeast(0)
    val days = safe / 1440
    val hours = (safe % 1440) / 60
    val mins = safe % 60
    return when {
        days > 0 -> "${days}d ${hours}h"
        hours > 0 -> "${hours}h ${mins}m"
        else -> "${mins} min"
    }
}

@Composable private fun FormFieldLabel(text: String) {
    Text(text, color = Color(0xFFD6E5F5), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
}

private fun workTypeIcon(type: String): ImageVector = when (type) {
    "Instalación" -> Icons.Default.Build
    "Revisión" -> Icons.Default.FactCheck
    "Solución" -> Icons.Default.Handyman
    "Mantenimiento" -> Icons.Default.HomeRepairService
    "Redes" -> Icons.Default.Lan
    "Hardware" -> Icons.Default.Memory
    else -> Icons.Default.Assignment
}

@Composable private fun ChoiceChips(options:List<String>,selected:String,onSelect:(String)->Unit) { Column(verticalArrangement=Arrangement.spacedBy(4.dp)) { options.chunked(4).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { row.forEach { item -> FilterChip(selected=item==selected,onClick={onSelect(item)},label={Text(item,style=MaterialTheme.typography.labelSmall)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Color(0xFF17394A),selectedLabelColor=Cyan)) } } } } }
@Composable private fun EmptyState(title:String,subtitle:String,icon:ImageVector) { AppCard { Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(vertical=18.dp)) { Icon(icon,null,tint=Cyan,modifier=Modifier.size(36.dp)); Spacer(Modifier.height(10.dp)); Text(title,fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(4.dp)); Text(subtitle,color=Muted,style=MaterialTheme.typography.bodySmall) } } } }
@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan, unfocusedBorderColor=Color(0xFF31465D), focusedLabelColor=Cyan, unfocusedLabelColor=Muted, cursorColor=Cyan, focusedTextColor=Color.White, unfocusedTextColor=Color.White)
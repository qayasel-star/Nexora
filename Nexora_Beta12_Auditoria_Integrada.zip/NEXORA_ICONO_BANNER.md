# Recursos visuales oficiales de Nexora — Beta 09

- `nexora_banner.png`: primera imagen enviada por el usuario, banner horizontal exacto.
- `nexora_brand_splash.png`: segunda imagen enviada por el usuario, diseño vertical de marca mostrado al abrir la aplicación durante 1,8 segundos.
- `ic_launcher.png` y `ic_launcher_round.png`: icono cuadrado original enviado anteriormente, solo redimensionado para las densidades de Android.

Las dos imágenes de banner y bienvenida se usan sin redibujar ni modificar su contenido. La bienvenida usa `ContentScale.Fit` para no recortar el diseño.

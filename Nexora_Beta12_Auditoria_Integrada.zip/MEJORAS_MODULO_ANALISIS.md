# Nexora Beta 10 — Módulo Análisis

## Cambios implementados

- Se conserva el módulo de análisis previo y sus indicadores de estado, resolución, duración media, departamento, software/equipo, prioridad y técnico.
- Selector de períodos con día actual, mes actual, año actual, intervalos rápidos (1, 2, 3 y 6 meses; 1 año), historial completo y rango personalizado.
- Rango personalizado de fecha inicial y final mediante calendarios nativos de Android; se normalizan los límites para incluir el día completo y se evita que el inicio quede después del final.
- Comparación con el intervalo anterior de igual duración para todos los rangos delimitados, con diferencias absolutas y porcentuales. El historial completo desactiva esta comparación por no tener una duración fija.
- Nueva vista ejecutiva con tasa de resolución y barra de distribución visual por estado.
- Nuevo gráfico de evolución de incidencias, agrupado según la extensión del intervalo.
- Las estadísticas usan registros locales reales. Los reportes resueltos se asignan por fecha de cierre cuando existe; los abiertos, por fecha de apertura.
- Versión fuente actualizada a `2.0-beta10`, `versionCode = 12`; el workflow publica `NEXORA-APK-v2.0-beta10`.

## Validación pendiente

Se revisaron los cambios en el código y la configuración del workflow. No fue posible ejecutar la compilación en este entorno porque no hay Gradle instalado y no se dispone de acceso de red para descargarlo. La validación definitiva debe realizarse en GitHub Actions.

# Recursos visuales oficiales de Nexora — Beta 08

- `app/src/main/res/mipmap-*/ic_launcher.png`: icono original proporcionado por el usuario, adaptado únicamente en tamaño para Android.
- `app/src/main/res/drawable-nodpi/nexora_banner.png`: banner horizontal exacto proporcionado por el usuario.
- `app/src/main/res/drawable-nodpi/nexora_brand_splash.png`: imagen cuadrada de identidad NEXORA proporcionada por el usuario.
- Nombre visible de Android: `Nexora`.
- Versión: `2.0-beta08` (`versionCode` 10).

El identificador de aplicación se conserva como `com.registroinformatico.app`.

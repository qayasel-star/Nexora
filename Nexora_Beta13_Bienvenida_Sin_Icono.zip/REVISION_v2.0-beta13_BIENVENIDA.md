# Nexora 2.0 Beta 13 — bienvenida sin icono nativo

## Cambios
- Se sustituyó el icono de la pantalla de arranque nativa de Android por un recurso transparente para evitar que aparezca el icono antes de la bienvenida animada.
- Se conserva la pantalla de bienvenida Compose existente: halo azul/cian pulsante, entrada gradual del logotipo, aparición secuencial del nombre y lema, y transición suave hacia la aplicación.
- No se cambia la arquitectura de datos ni se implementa la futura conexión con SQL Server.

## Validación
- Cambio de recursos XML realizado y revisado.
- La compilación Android y las pruebas en dispositivo no se han ejecutado en este entorno; deben verificarse antes de distribuir el APK.
